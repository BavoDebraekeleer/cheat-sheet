/*
 * Daan Dekoning
 * LedFader library 24/09/2021
 */
#include "Arduino.h"
#include "LedFader.h"

LedFader::LedFader(int pin)
{
    pinMode(pin, OUTPUT);
    _pin = pin;
}

void LedFader::fadein(int time)
{
    for (int helderheid = 0; helderheid <= MAX_HELDERHEID; helderheid++)
    {
        analogWrite(_pin, helderheid);
        delay(time / MAX_HELDERHEID);
    }
}

void LedFader::fadeout(int time)
{
    for (int helderheid = MAX_HELDERHEID; helderheid >= 0; --helderheid)
    {
        analogWrite(_pin, helderheid);
        delay(time / MAX_HELDERHEID);
    }
}