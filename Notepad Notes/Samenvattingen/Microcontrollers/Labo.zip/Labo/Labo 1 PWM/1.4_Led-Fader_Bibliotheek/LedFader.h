/*
 * Daan Dekoning
 * LedFader library 24/09/2021
 */
#ifndef LedFader_h
#define LedFader_h
#define MAX_HELDERHEID 255

#include "Arduino.h"

class LedFader
{
public:
    LedFader(int pin);
    void fadein(int time);
    void fadeout(int time);

private:
    int _pin;
};

#endif