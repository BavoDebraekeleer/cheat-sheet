#include <Arduino.h>
#line 1 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
#line 1 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
void setup();
#line 69 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
void loop();
#line 92 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
void nieuweDelay(byte tijd);
#line 1 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
void setup()
{
    Serial.begin(9600);
    Serial.println("Opstarten.");
/*
     * LEDS
     */
#define GROEN PC0
#define GEEL PC1
#define ROOD PC2
    DDRC |= (1 << GROEN);
    DDRC |= (1 << GEEL);
    DDRC |= (1 << ROOD);

    PORTC |= (1 << PC0);
    PORTC |= (1 << PC1);
    PORTC |= (1 << PC2);

    /*
     * TC0 1562.5Hz
     */
    // OC0A als output
    DDRD |= (1 << PD6);
    // Compare output mode = Toggle OC0A on Compare Match.
    TCCR0A &= ~(1 << COM0A1);
    TCCR0A |= (1 << COM0A0);
    // Waveform Generation Mode 2 CTC `010`
    TCCR0B &= ~(1 << WGM02);
    TCCR0A |= (1 << WGM01);
    TCCR0A &= ~(1 << WGM00);
    // Pre-Scaler = 256 `100`
    TCCR0B |= (1 << CS02);
    TCCR0B &= ~(1 << CS01);
    TCCR0B &= ~(1 << CS00);
    OCR0A = 20;

    /*
     * TC1 TC0 als externe klok soruce
     */
    // INT1 UITGANG
    DDRD |= (1 << PD3);
    // OC1A als output (D9)
    DDRB |= (1 << PB1);
    // T1 als input
    DDRD |= (1 << PD5);
    // Toggle OC1A on Compare Match `01`
    TCCR1A &= ~(1 << COM1A1);
    TCCR1A |= (1 << COM1A0);
    // CTC Mode  WGM12 1
    TCCR1B |= (1 << WGM12);
    // Clock source setting T1 (D5) pin falling edge
    TCCR1B |= (1 << CS12);
    TCCR1B |= (1 << CS11);
    TCCR1B &= ~(1 << CS10);
    TCCR1C = 0x00;
    // int tot_ocr1a = 781;
    // OCR1A = tot_ocr1a;
    OCR1AH = 0b00000011;
    OCR1AL = 0b00001101;
    //  Output masks
    TIMSK1 |= (1 << 1);
    TIMSK1 |= (1 << 0);
    TIFR1 |= (1 << 1);
    TIFR1 |= (1 << 0);

    DDRB &= ~(1 << PB3);
}

void loop()
{
    if (PINB & (1 << PB3))
    {
        // Gewoon rood licht
        PORTC |= (1 << ROOD);
        PORTC &= ~(1 << GEEL);
        PORTC &= ~(1 << GROEN);
    }
    else
    {
        // enkel geel
        PORTC |= (1 << GEEL);
        PORTC &= ~(1 << ROOD);
        PORTC &= ~(1 << GROEN);
    }
}

ISR(TIMER1_COMPA_vect)
{
    PORTD ^= (1 << PD3);
}

void nieuweDelay(byte tijd)
{
    // Het is de bedoeling dat bij tijd het aantal
    // seconden wordt meegegeven dat voor de delay.
    byte loops = 0;
    while (tijd != loops)
    {
        // code om TC1 die op 1Hz staat ingesteld x aantal keer te laten tellen
    }
}
