# 1 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
void setup()
{
    Serial.begin(9600);
    Serial.println("Opstarten.");
/*

     * LEDS

     */

    
# 11 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x07) + 0x20)) 
# 11 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
        |= (1 << 
# 11 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                 0
# 11 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                      );
    
# 12 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x07) + 0x20)) 
# 12 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
        |= (1 << 
# 12 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                 1
# 12 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                     );
    
# 13 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x07) + 0x20)) 
# 13 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
        |= (1 << 
# 13 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                 2
# 13 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                     );

    
# 15 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x08) + 0x20)) 
# 15 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
         |= (1 << 
# 15 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                  0
# 15 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                     );
    
# 16 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x08) + 0x20)) 
# 16 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
         |= (1 << 
# 16 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                  1
# 16 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                     );
    
# 17 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x08) + 0x20)) 
# 17 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
         |= (1 << 
# 17 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                  2
# 17 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                     );

    /*

     * TC0 1562.5Hz

     */
# 22 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
    // OC0A als output
    
# 23 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x0A) + 0x20)) 
# 23 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
        |= (1 << 
# 23 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                 6
# 23 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                    );
    // Compare output mode = Toggle OC0A on Compare Match.
    
# 25 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x24) + 0x20)) 
# 25 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
          &= ~(1 << 
# 25 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                    7
# 25 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                          );
    
# 26 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x24) + 0x20)) 
# 26 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
          |= (1 << 
# 26 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                   6
# 26 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                         );
    // Waveform Generation Mode 2 CTC `010`
    
# 28 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x25) + 0x20)) 
# 28 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
          &= ~(1 << 
# 28 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                    3
# 28 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                         );
    
# 29 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x24) + 0x20)) 
# 29 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
          |= (1 << 
# 29 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                   1
# 29 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                        );
    
# 30 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x24) + 0x20)) 
# 30 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
          &= ~(1 << 
# 30 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                    0
# 30 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                         );
    // Pre-Scaler = 256 `100`
    
# 32 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x25) + 0x20)) 
# 32 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
          |= (1 << 
# 32 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                   2
# 32 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                       );
    
# 33 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x25) + 0x20)) 
# 33 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
          &= ~(1 << 
# 33 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                    1
# 33 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                        );
    
# 34 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x25) + 0x20)) 
# 34 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
          &= ~(1 << 
# 34 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                    0
# 34 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                        );
    
# 35 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x27) + 0x20)) 
# 35 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
         = 20;

    /*

     * TC1 TC0 als externe klok soruce

     */
# 40 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
    // INT1 UITGANG
    
# 41 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x0A) + 0x20)) 
# 41 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
        |= (1 << 
# 41 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                 3
# 41 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                    );
    // OC1A als output (D9)
    
# 43 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x04) + 0x20)) 
# 43 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
        |= (1 << 
# 43 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                 1
# 43 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                    );
    // T1 als input
    
# 45 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x0A) + 0x20)) 
# 45 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
        |= (1 << 
# 45 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                 5
# 45 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                    );
    // Toggle OC1A on Compare Match `01`
    
# 47 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)(0x80)) 
# 47 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
          &= ~(1 << 
# 47 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                    7
# 47 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                          );
    
# 48 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)(0x80)) 
# 48 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
          |= (1 << 
# 48 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                   6
# 48 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                         );
    // CTC Mode  WGM12 1
    
# 50 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)(0x81)) 
# 50 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
          |= (1 << 
# 50 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                   3
# 50 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                        );
    // Clock source setting T1 (D5) pin falling edge
    
# 52 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)(0x81)) 
# 52 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
          |= (1 << 
# 52 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                   2
# 52 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                       );
    
# 53 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)(0x81)) 
# 53 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
          |= (1 << 
# 53 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                   1
# 53 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                       );
    
# 54 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)(0x81)) 
# 54 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
          &= ~(1 << 
# 54 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                    0
# 54 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                        );
    
# 55 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)(0x82)) 
# 55 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
          = 0x00;
    // int tot_ocr1a = 781;
    // OCR1A = tot_ocr1a;
    
# 58 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)(0x89)) 
# 58 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
          = 0b00000011;
    
# 59 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)(0x88)) 
# 59 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
          = 0b00001101;
    //  Output masks
    
# 61 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)(0x6F)) 
# 61 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
          |= (1 << 1);
    
# 62 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)(0x6F)) 
# 62 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
          |= (1 << 0);
    
# 63 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x16) + 0x20)) 
# 63 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
         |= (1 << 1);
    
# 64 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x16) + 0x20)) 
# 64 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
         |= (1 << 0);

    
# 66 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x04) + 0x20)) 
# 66 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
        &= ~(1 << 
# 66 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                  3
# 66 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                     );
}

void loop()
{
    if (
# 71 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
       (*(volatile uint8_t *)((0x03) + 0x20)) 
# 71 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
            & (1 << 
# 71 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                    3
# 71 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                       ))
    {
        // Gewoon rood licht
        
# 74 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
       (*(volatile uint8_t *)((0x08) + 0x20)) 
# 74 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
             |= (1 << 
# 74 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                      2
# 74 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                          );
        
# 75 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
       (*(volatile uint8_t *)((0x08) + 0x20)) 
# 75 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
             &= ~(1 << 
# 75 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                       1
# 75 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                           );
        
# 76 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
       (*(volatile uint8_t *)((0x08) + 0x20)) 
# 76 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
             &= ~(1 << 
# 76 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                       0
# 76 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                            );
    }
    else
    {
        // enkel geel
        
# 81 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
       (*(volatile uint8_t *)((0x08) + 0x20)) 
# 81 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
             |= (1 << 
# 81 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                      1
# 81 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                          );
        
# 82 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
       (*(volatile uint8_t *)((0x08) + 0x20)) 
# 82 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
             &= ~(1 << 
# 82 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                       2
# 82 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                           );
        
# 83 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
       (*(volatile uint8_t *)((0x08) + 0x20)) 
# 83 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
             &= ~(1 << 
# 83 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                       0
# 83 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                            );
    }
}


# 87 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
extern "C" void __vector_11 /* Timer/Counter1 Compare Match A */ (void) __attribute__ ((signal,used, externally_visible)) ; void __vector_11 /* Timer/Counter1 Compare Match A */ (void)

# 88 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
{
    
# 89 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
   (*(volatile uint8_t *)((0x0B) + 0x20)) 
# 89 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
         ^= (1 << 
# 89 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino" 3
                  3
# 89 "c:\\Users\\Daan Dekoning\\Documents\\Vakken\\Microcontrollers\\Labo\\EXAMEN\\vaardigheidsproef\\vaardigheidsproef.ino"
                     );
}

void nieuweDelay(byte tijd)
{
    // Het is de bedoeling dat bij tijd het aantal
    // seconden wordt meegegeven dat voor de delay.
    byte loops = 0;
    while (tijd != loops)
    {
        // code om TC1 die op 1Hz staat ingesteld x aantal keer te laten tellen
    }
}
