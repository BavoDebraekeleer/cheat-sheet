from abc import ABC
from datetime import datetime


class Brood(ABC):
    GROOTTE = 0
    KEY = ''

    def __init__(self, bakmoment: datetime):
        self.bakmoment = bakmoment
        pass


class KleinBrood(Brood, ABC):
    GROOTTE = 0.5

    def __init__(self, bakmoment: datetime):
        super(KleinBrood, self).__init__(bakmoment)


class GrootBrood(Brood, ABC):
    GROOTTE = 1

    def __init__(self, bakmoment: datetime):
        super(GrootBrood, self).__init__(bakmoment)


class VolkorenBrood(GrootBrood):
    KEY = 'volkoren_brood'

    def __init__(self, bakmoment: datetime):
        super().__init__(bakmoment)


class WitBrood(GrootBrood):
    KEY = 'wit_brood'

    def __init__(self, bakmoment: datetime):
        super().__init__(bakmoment)


class MeergranenBrood(GrootBrood):
    KEY = 'meergranen_brood'

    def __init__(self, bakmoment: datetime):
        super().__init__(bakmoment)


class ZuurdesemBrood(KleinBrood):
    KEY = 'zuurdesem_brood'

    def __init__(self, bakmoment: datetime):
        super().__init__(bakmoment)


class RozijnenBrood(KleinBrood):
    KEY = 'rozijnen_brood'

    def __init__(self, bakmoment: datetime):
        super().__init__(bakmoment)


if __name__ == "__main__":
    oWitbrood = WitBrood(datetime.now())
