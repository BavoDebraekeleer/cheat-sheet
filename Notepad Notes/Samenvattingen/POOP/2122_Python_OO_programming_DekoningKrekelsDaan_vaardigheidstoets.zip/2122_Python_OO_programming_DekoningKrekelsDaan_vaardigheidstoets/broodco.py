from datetime import datetime
from random import Random

from koerier import Koerier

from broodautomaat import GroteBroodAutomaat, BroodAutomaat


class BroodCo:
    def __init__(self, aantal_gewone_automaten, aantal_grote_automaten):
        self.aantal_gewone_automaten = aantal_gewone_automaten
        self.aantal_grote_automaten = aantal_grote_automaten
        self.automaten = {
            'gewone_automaten': [],
            'grote_automaten': []
        }
        self.broden = {}
        for i in range(aantal_gewone_automaten):
            self.automaten['gewone_automaten'].append(BroodAutomaat(i))

        for i in range(aantal_grote_automaten):
            self.automaten['grote_automaten'].append(GroteBroodAutomaat(i))

    def __repr__(self):
        ret = ''
        for soort in self.automaten:
            for automaat in self.automaten[soort]:
                ret += '\t' + str(automaat) + '\n'

        if len(self.broden) == 0:
            ret += "Alle broden zijn op"
        for brood in self.broden:
            ret += brood + ", "
        return ret

    def bakken(self, *broden_aantal):
        """
        Geef broden in om te bakken in de vorm: [Brood(),AANTAL],[AnderBrood(),Aantal]
        :param broden_aantal: []
        """
        for soort, aantal_broden in broden_aantal:
            if soort.KEY not in self.broden:
                self.broden.update({soort.KEY: []})
            for i in range(aantal_broden):
                vers_brood = soort(datetime.now())
                self.broden[soort.KEY].append(vers_brood)
            print(f"{aantal_broden} {soort.KEY} gebakken.")

    def geef_willekeurig_brood(self, koerier: Koerier):
        soort = Random().randint(0, len(self.broden) - 1)
        brood_namen = list(self.broden)
        koerier.ontvang_brood(self.broden[brood_namen[soort]].pop())
        if len(self.broden[brood_namen[soort]]) == 0:
            del self.broden[brood_namen[soort]]

    def kies_automaat(self) -> BroodAutomaat:
        gevonden = False
        automaat = None
        while not gevonden:
            soort_automaat = list(self.automaten)[Random().randint(0, len(self.automaten) - 1)]
            gekozen_automaat = Random().randint(0, len(self.automaten[soort_automaat]) - 1)
            automaat = self.automaten[soort_automaat][gekozen_automaat]
            if automaat.vrije_ruimte > 0:
                gevonden = True
        return automaat
