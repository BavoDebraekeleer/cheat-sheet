from random import Random

from brood import Brood
from broodautomaat import BroodAutomaat


class Koerier():
    def __init__(self):
        self.broden = {}

    def __repr__(self):
        ret = ''
        if len(self.broden) == 0:
            ret += "Al mijn broden zijn op"
        for brood in self.broden:
            ret += brood + ", "
        return ret

    def ontvang_brood(self, brood: Brood):
        if brood.KEY not in self.broden:
            self.broden.update({brood.KEY: []})
        self.broden[brood.KEY].append(brood)

    def plaats_brood(self, automaat: BroodAutomaat, aantal: int = 100):
        if len(self.broden) == 0:
            print("Mijn broden zijn op.")
            return
        nieuwe_broden = {}
        for i in range(aantal):
            soort = Random().randint(0, len(self.broden) - 1)
            brood_namen = list(self.broden)
            if brood_namen[soort] not in nieuwe_broden:
                nieuwe_broden.update({brood_namen[soort]: []})
            nieuwe_broden[brood_namen[soort]].append(self.broden[brood_namen[soort]].pop())
            if len(self.broden[brood_namen[soort]]) == 0:
                del self.broden[brood_namen[soort]]
        print(nieuwe_broden)
        automaat.broodToevoegen(**nieuwe_broden)
