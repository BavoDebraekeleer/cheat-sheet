from datetime import datetime
from random import Random
from brood import Brood


class Klant():
    def __init__(self):
        self.broden = {}
        self.bezoeken = []

    def __repr__(self):
        ret = 'Klant: \n'
        if self.bezoeken is not None:
            for bezoek in self.bezoeken:
                ret += f"\t{bezoek[0]} aan {bezoek[1]} op {bezoek[2]}\n"
        ret += '\t'
        for brood in self.broden:
            ret += brood + ", "
        return ret

    def kies(self, keuze):
        gekozen = keuze[Random().randint(0, len(keuze) - 1)]
        return gekozen

    def ontvang_brood(self, brood: Brood):
        if brood.KEY not in self.broden:
            self.broden.update({brood.KEY: []})
        self.broden[brood.KEY].append(brood)

    def registreer_bezoek(self, broodsoort, automaat, tijd: datetime):
        self.bezoeken.append([broodsoort, automaat, tijd])
