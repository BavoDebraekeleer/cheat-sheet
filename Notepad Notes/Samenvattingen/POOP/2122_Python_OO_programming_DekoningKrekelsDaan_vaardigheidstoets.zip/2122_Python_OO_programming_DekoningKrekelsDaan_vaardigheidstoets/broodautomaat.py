from datetime import datetime

from brood import Brood
from klant import Klant


class BroodAutomaat:
    CAPACITEIT = 75
    TYPE = 'gewone_automaat'

    def __init__(self, id):
        self.id = id
        self.vrije_ruimte = self.CAPACITEIT
        self.broden = {}

    def __repr__(self):
        ret = f'{self.TYPE} {self.vrije_ruimte}/{self.CAPACITEIT}  '
        for brood in self.broden:
            ret += brood + ", "
        return ret

    def verkoopBrood(self, klant: Klant):
        if self.vrije_ruimte == 0:
            print("Sorry, deze automaat is leeg.")
            return
        print("Wat voor type brood wenst u?")
        keuze = klant.kies(list(self.broden))
        print(f"\t-{keuze}")
        klant.ontvang_brood(self.broden[keuze].pop())
        klant.registreer_bezoek(keuze, f"{self.TYPE} {self.id}", datetime.now())

    def broodToevoegen(self, **broden):
        for soort, broden in broden.items():
            if soort not in self.broden:
                self.broden.update({soort: []})
            for brood in broden:
                if not isinstance(brood, Brood):
                    raise ValueError("Brood moet Brood zijn.")

                if self.vrije_ruimte >= brood.GROOTTE:
                    self.broden[soort].append(brood)
                    self.vrije_ruimte -= brood.GROOTTE
                else:
                    print("Deze automaat is vol.")
                    return

    def broodVerwijderen(self, **broden_aantal):
        teruggeven = {}
        for soort, aantal_broden in broden_aantal.items():
            if soort not in self.broden:
                print("Dit brood zit hier niet in.")
                return teruggeven
            if soort not in teruggeven:
                self.broden.update({soort: []})
            for brood in range(aantal_broden):
                if self.vrije_ruimte != self.CAPACITEIT:
                    weg_brood = self.broden[soort].pop(1)
                    teruggeven[soort].append(weg_brood)
                    self.vrije_ruimte += weg_brood.GROOTTE
                else:
                    print("Deze automaat is leeg.")
                    return teruggeven
        return teruggeven


class GroteBroodAutomaat(BroodAutomaat):
    CAPACITEIT = 105
    TYPE = 'grote_automaat'

    def __init__(self, id):
        super(GroteBroodAutomaat, self).__init__(id)
