from broodco import BroodCo
from brood import VolkorenBrood, WitBrood, MeergranenBrood, ZuurdesemBrood, RozijnenBrood
from koerier import Koerier
from klant import Klant

oBroodCo = BroodCo(20, 5)

# Bakmoment
print("Bakmoment")
aantal = 300
oBroodCo.bakken([VolkorenBrood, aantal], [WitBrood, aantal], [MeergranenBrood, aantal], [ZuurdesemBrood, aantal],
                [RozijnenBrood, aantal])

# Koeriers worden aangemaakt
print("Koeriers worden aangemaakt")
oKoerier1 = Koerier()
oKoerier2 = Koerier()
oKoerier3 = Koerier()
oKoerier4 = Koerier()
oKoerier5 = Koerier()

# Alle gebakken broden worden aan de koeriers uitgedeeld
print("Alle gebakken broden worden aan de koeriers uitgedeeld")
for i in range(300):
    oBroodCo.geef_willekeurig_brood(oKoerier1)
    oBroodCo.geef_willekeurig_brood(oKoerier2)
    oBroodCo.geef_willekeurig_brood(oKoerier3)
    oBroodCo.geef_willekeurig_brood(oKoerier4)
    oBroodCo.geef_willekeurig_brood(oKoerier5)

print(oKoerier1)
print(oKoerier2)
print(oKoerier3)
print(oKoerier4)
print(oKoerier5)

#  Alle koeriers plaatsen broden
print("Alle koeriers plaatsen broden")
for i in range(300):
    oKoerier1.plaats_brood(oBroodCo.kies_automaat(), 1)
    oKoerier2.plaats_brood(oBroodCo.kies_automaat(), 1)
    oKoerier3.plaats_brood(oBroodCo.kies_automaat(), 1)
    oKoerier4.plaats_brood(oBroodCo.kies_automaat(), 1)
    oKoerier5.plaats_brood(oBroodCo.kies_automaat(), 1)

print(oBroodCo)

# Klanten worden aangemaakt
print("Klanten worden aangemaakt")
oKlant1 = Klant()
oKlant2 = Klant()
oKlant3 = Klant()
oKlant4 = Klant()
oKlant5 = Klant()

# Klanten kopen broden
print("Klanten kopen broden")
automaat = oBroodCo.kies_automaat()
automaat.verkoopBrood(oKlant1)

automaat = oBroodCo.kies_automaat()
automaat.verkoopBrood(oKlant2)

automaat = oBroodCo.kies_automaat()
automaat.verkoopBrood(oKlant5)

automaat = oBroodCo.kies_automaat()
automaat.verkoopBrood(oKlant1)
print(oKlant1)

